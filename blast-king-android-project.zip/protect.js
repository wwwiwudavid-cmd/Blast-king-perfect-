// Scrambles the game code in www/index.html so copies are harder to read and edit.
// Safe by design: if anything looks wrong the build falls back to the normal file.
const fs = require('fs'), vm = require('vm');
const file = 'www/index.html';
const html = fs.readFileSync(file, 'utf8');
const open = html.indexOf('<script>'), close = html.lastIndexOf('</script>');
if (open < 0 || close < open) throw new Error('game script not found');
const next = html.indexOf('<script>', open + 8);
if (next !== -1 && next < close) throw new Error('more than one script block');
const code = html.slice(open + 8, close);
const O = require('javascript-obfuscator');
let out = O.obfuscate(code, {
  compact: true, simplify: true, target: 'browser',
  identifierNamesGenerator: 'mangled',
  renameGlobals: false, renameProperties: false,        // keep names the game and Android plugin rely on
  stringArray: true, stringArrayThreshold: 0.7, stringArrayEncoding: ['base64'],
  stringArrayRotate: true, stringArrayShuffle: true,
  splitStrings: false, transformObjectKeys: false, unicodeEscapeSequence: false,
  controlFlowFlattening: false, deadCodeInjection: false,   // these slow the game down on cheap phones
  selfDefending: false, debugProtection: false, disableConsoleOutput: false
}).getObfuscatedCode();
out = out.replace(/<\/script/gi, '<\\/script');
new vm.Script(out);                                      // must still be valid JavaScript
if (out.length < code.length * 0.3) throw new Error('output suspiciously small');
fs.writeFileSync(file, html.slice(0, open + 8) + out + html.slice(close));
console.log('Protected game code:', code.length, '->', out.length, 'bytes');
